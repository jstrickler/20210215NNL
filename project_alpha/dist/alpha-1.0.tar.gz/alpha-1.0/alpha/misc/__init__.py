"""
Helper routines for project Alpha
"""
#  convenience imports
#  shared code

print("Importing alpha.misc")