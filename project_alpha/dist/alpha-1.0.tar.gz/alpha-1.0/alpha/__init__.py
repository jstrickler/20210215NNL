"""
This is project alpha

It is wonderful, and here's what it does:

Blah blah-dy blah
"""
# "convenience import"
from project_alpha.alpha.misc.utils import spam
print("importing alpha")
TEXAS_BREAKFAST = ["snakes", "steaks", "PhDs"]
import sqlite3
db_conn = sqlite3.connect('DATA/presidents.db')