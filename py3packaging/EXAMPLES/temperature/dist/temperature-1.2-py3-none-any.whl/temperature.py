
def c2f(cel):
    cel = float(cel)
    f = ((9 * cel) / 5 ) + 32

    return f

def f2c(fahr):
    fahr = float(fahr)
    c = (fahr - 32) * (5.0/9)
    
    return c
